out = io.open("foo.txt", "w")
out:close()

while true do

emu.frameadvance();
end